class AppImages {
  static const basePath = 'assets/images/';
  static const String kImageBase = 'https://image.tmdb.org/t/p/w500';

  static const splashBackground = '${basePath}splash-bg.png';
}
