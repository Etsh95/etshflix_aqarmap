import 'package:flutter/material.dart';

class AppColors {
  static const primary = Color(0xffe21221);
  static const background = Color(0xff181a20);
  static const secondBackground = Color(0xff35383f);
}